/**
This class generates IndexException objects for the Array<T> interface
*/
public class IndexException extends Exception {
    public static final long serialVersionUID = 0;
}
