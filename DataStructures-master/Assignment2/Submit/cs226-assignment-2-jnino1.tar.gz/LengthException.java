/**
This class generates LengthException objects for the Array<T> interface
*/
public class LengthException extends Exception {
    public static final long serialVersionUID = 0;
}
