/*Jose Nino - jnino1@jhu.edu
Data Structures - Assignment 1
*/

public interface ResetableCounter extends Counter {
	/** Resets the value of the Counter */
	void reset();
}